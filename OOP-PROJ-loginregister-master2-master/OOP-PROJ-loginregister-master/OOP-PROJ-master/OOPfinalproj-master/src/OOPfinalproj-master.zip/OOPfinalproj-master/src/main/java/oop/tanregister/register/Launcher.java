package oop.tanregister.register;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(Registration.class, args);
    }
}
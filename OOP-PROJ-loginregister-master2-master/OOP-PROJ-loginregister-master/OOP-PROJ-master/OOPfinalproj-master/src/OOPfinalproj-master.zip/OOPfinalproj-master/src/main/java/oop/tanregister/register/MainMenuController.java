package oop.tanregister.register;

public class MainMenuController {
}
